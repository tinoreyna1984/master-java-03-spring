package com.andres.curso.springboot.webapp.springbootweb.models.dto;

public class ParamDto {
    
    private String message;

    
    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    
}
