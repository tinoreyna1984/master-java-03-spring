package com.example.demo.controller.dto;

public record CarDto(Integer id, String brand, Integer kilowatt) {
}
