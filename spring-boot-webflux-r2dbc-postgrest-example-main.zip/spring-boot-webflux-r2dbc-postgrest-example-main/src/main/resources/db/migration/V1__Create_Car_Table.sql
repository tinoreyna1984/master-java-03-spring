create table car (
    id SERIAL,
    brand varchar(255),
    kilowatt integer,
    constraint car_pk primary key (id)
);