# spring-boot-webflux-r2dbc-postgrest-example
spring-boot-webflux-r2dbc-postgrest-example


In this folder run `docker compose up` which will use the `docker-compose.yml` file to start postgresDB as docker container.

Then just start the spring boot application by running the `DemoApplication` main class.

See the `resources.properties` for important configuration parameters. 