package com.andres.curso.springboot.di.factura.springbootdifactura;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDifacturaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDifacturaApplication.class, args);
	}

}
