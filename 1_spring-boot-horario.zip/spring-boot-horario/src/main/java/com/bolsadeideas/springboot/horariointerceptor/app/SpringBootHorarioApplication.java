package com.bolsadeideas.springboot.horariointerceptor.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootHorarioApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootHorarioApplication.class, args);
	}

}
