package com.bolsadeideas.springboot.di.app.models.service;

public interface IServicio {

	public String operacion();
}
