package com.bolsadeideas.springboot.error.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootErrorApplicationTests {

	@Test
	void contextLoads() {
	}

}
